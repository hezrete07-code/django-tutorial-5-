# Django Tutorial 5: Otomatik Testler

Bu proje, Django resmi eğitiminin 5. bölümünü (Otomatik Testler) uygulamaktadır. Proje, önceki bölümlerde (1-4) oluşturulan anket uygulamasını içerir ve `was_published_recently()` metodundaki bir hatayı ortaya çıkarmak ve düzeltmek için testler ekler.

## Projeyi Çalıştırma Talimatları

Öğretmeninizin projeyi kolayca çalıştırabilmesi için aşağıdaki adımları izleyin:

### 1. Sanal Ortam Oluşturma ve Etkinleştirme

Projeyi izole bir ortamda çalıştırmak için bir sanal ortam oluşturun ve etkinleştirin:

\`\`\`bash
python3 -m venv venv
source venv/bin/activate
\`\`\`

### 2. Bağımlılıkları Yükleme

Gerekli Python paketlerini (sadece Django) yükleyin:

\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 3. Veritabanı Geçişlerini Uygulama

Proje modellerini veritabanına uygulamak için geçişleri çalıştırın:

\`\`\`bash
python manage.py migrate
\`\`\`

### 4. Testleri Çalıştırma (Tutorial 5'in Ana Bölümü)

Uygulamanın doğru çalıştığını ve Tutorial 5'te eklenen testlerin geçtiğini kontrol edin:

\`\`\`bash
python manage.py test polls
\`\`\`

Tüm testlerin **OK** olarak geçmesi gerekir.

### 5. Geliştirme Sunucusunu Başlatma (İsteğe Bağlı)

Uygulamayı tarayıcıda görmek isterseniz, geliştirme sunucusunu başlatın:

\`\`\`bash
python manage.py runserver
\`\`\`

Ardından tarayıcınızda `http://127.0.0.1:8000/` adresine gidin. (Not: Veritabanında anket verisi olmadığı için "No polls are available." mesajını görebilirsiniz. Yönetici arayüzünden veri ekleyebilirsiniz.)

### 6. Yönetici Kullanıcısı Oluşturma (İsteğe Bağlı)

Yönetici arayüzüne erişmek ve anket verisi eklemek için bir süper kullanıcı oluşturun:

\`\`\`bash
python manage.py createsuperuser
\`\`\`

Ardından `http://127.0.0.1:8000/admin/` adresine giderek giriş yapabilirsiniz.
